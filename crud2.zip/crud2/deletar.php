<?php 

    require "conexao.php";

    $id = $_GET['id'];
    $sql = "DELETE FROM alunos where id = :id";

    $stmt = $pdo ->prepare($sql);

    $stmt -> execute(
        [
            ':id' => $id
        ]
    );

    header("Locatio:index.php");


?>